#' Analyzing beta drift
#'
#' bdrift provides tools for analyzing and
#' visualizing beta drift in multi-factor models.
#'
#' @docType package
#' @name bdrift-package
#' @aliases bdrift
NULL
